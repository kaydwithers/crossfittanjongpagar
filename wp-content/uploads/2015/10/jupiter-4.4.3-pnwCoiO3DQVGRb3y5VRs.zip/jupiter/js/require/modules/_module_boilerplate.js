define(['jquery', 'window'], function($, win) {
	'use strict';

	var Public = {
		init: init
	};

	function init(config) {

	}

	return Public;

});